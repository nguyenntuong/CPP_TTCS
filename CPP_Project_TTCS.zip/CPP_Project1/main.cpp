#include "App.h"

int main() {
	int res = App::run();
	return res;
}