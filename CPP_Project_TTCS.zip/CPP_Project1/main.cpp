#include "App.h"

int main() {
	int res = App::Run();
	return res;
}