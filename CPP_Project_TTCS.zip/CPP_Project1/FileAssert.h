#pragma once
#include <string>
#include<fstream>
#include "ListControl.h"
#include "Utils.h"
using namespace std;
class FileAssert
{
private:
	string path;
public:
	FileAssert();
	FileAssert(string path);
	~FileAssert();
public:
	ListControl<NhanVien>* ReadFromText(bool=true);
	static bool WriteTo(string, ListControl<NhanVien>*);
};

